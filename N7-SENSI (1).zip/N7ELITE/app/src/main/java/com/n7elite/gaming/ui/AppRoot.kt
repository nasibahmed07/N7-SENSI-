package com.n7elite.gaming.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.n7elite.gaming.ui.theme.N7Blue
import com.n7elite.gaming.ui.theme.N7Red

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val cfg by vm.cfg.collectAsState()
    var screen by rememberSaveable { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }
    val back = { screen = "home" }
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        when {
            cfg.ok && vm.deviceId in cfg.blocked -> Notice("Access blocked", "The admin blocked this device.")
            cfg.ok && cfg.maintenance -> Notice("Maintenance", cfg.message.ifBlank { "Back soon." })
            cfg.ok && cfg.minVersion > APP_VERSION -> Notice("Update required", "Install the newest N7 SENSI to continue.")
            else -> when (screen) {
                "sensi" -> SensiScreen(vm, back)
                "train" -> TrainingScreen(back)
                "profiles" -> ProfilesScreen(vm, back)
                "admin" -> AdminScreen(vm, back)
                else -> HomeScreen(vm) { screen = it }
            }
        }
    }
}

@Composable
private fun Notice(title: String, text: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = N7Red)
        Spacer(Modifier.height(8.dp))
        Text(text)
    }
}

@Composable
private fun HomeScreen(vm: AppViewModel, go: (String) -> Unit) {
    val cfg by vm.cfg.collectAsState()
    val d = vm.device
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("N7 SENSI", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = N7Red)
        Text("Free Fire control dashboard", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
        if (cfg.ok && cfg.message.isNotBlank()) GlassCard {
            Text("Announcement", fontWeight = FontWeight.Bold, color = N7Blue)
            Text(cfg.message, modifier = Modifier.padding(top = 4.dp))
        }
        GlassCard {
            Text("This phone", fontWeight = FontWeight.Bold, color = N7Blue, fontSize = 18.sp)
            KV("Device", "${d.brand} ${d.model}")
            KV("System", d.androidVersion)
            KV("RAM (reported)", "%.1f GB".format(d.ramGb))
            KV("Screen", "%.2f inch".format(d.screenInches))
            KV("Resolution", "${d.widthPx} x ${d.heightPx}")
            KV("DPI", d.dpi.toString())
            KV("Refresh rate", "${d.refreshHz} Hz")
        }
        Nav("Sensitivity Manager", "Phone list, custom DPI, sensi 0 to 200, button sizes") { go("sensi") }
        Nav("Aim Training", "30 second tap test with real hit and accuracy numbers") { go("train") }
        Nav("Gaming Profiles", "Your saved setups") { go("profiles") }
        Nav("Cloud and Admin", "Remote settings, announcements, block list") { go("admin") }
        GlassCard {
            Text("Recoil Simulator", fontWeight = FontWeight.Bold)
            Text("Not built yet. It needs real weapon pattern data.", modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun Nav(title: String, about: String, onClick: () -> Unit) {
    GlassCard(onClick = onClick) {
        Text(title, fontWeight = FontWeight.Bold)
        Text(about, modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
    }
}

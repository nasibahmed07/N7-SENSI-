package com.n7elite.gaming.ui

import android.app.Application
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.n7elite.gaming.data.RemoteConfig
import com.n7elite.gaming.data.Store
import com.n7elite.gaming.data.fetchConfig
import com.n7elite.gaming.data.readDeviceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

const val APP_VERSION = 1

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    val device = readDeviceInfo(app)
    val deviceId: String = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    var url by mutableStateOf(store.configUrl)
        private set

    private val _cfg = MutableStateFlow(RemoteConfig())
    val cfg: StateFlow<RemoteConfig> = _cfg.asStateFlow()

    private val _profiles = MutableStateFlow(store.profiles())
    val profiles: StateFlow<Map<String, String>> = _profiles.asStateFlow()

    init { refresh() }

    fun refresh() {
        if (url.isBlank()) return
        viewModelScope.launch { _cfg.value = fetchConfig(url) }
    }

    fun updateUrl(u: String) {
        url = u.trim()
        store.configUrl = url
        refresh()
    }

    fun saveProfile(name: String, text: String) {
        store.saveProfile(name, text)
        _profiles.value = store.profiles()
    }

    fun deleteProfile(name: String) {
        store.deleteProfile(name)
        _profiles.value = store.profiles()
    }
}

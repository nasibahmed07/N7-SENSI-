package com.n7elite.gaming.data

import com.n7elite.gaming.logic.Phone

object Phones {
    val brands: Map<String, List<Phone>> = linkedMapOf(
        "Samsung" to listOf(
            Phone("Galaxy A04e", 6.5, 720, 1600, 60),
            Phone("Galaxy A05", 6.7, 1080, 2400, 60),
            Phone("Galaxy A14", 6.6, 1080, 2408, 90),
            Phone("Galaxy A15", 6.5, 1080, 2340, 90),
            Phone("Galaxy A25", 6.5, 1080, 2340, 120),
            Phone("Galaxy A35", 6.6, 1080, 2340, 120),
            Phone("Galaxy A54", 6.4, 1080, 2340, 120),
            Phone("Galaxy M14", 6.6, 1080, 2408, 90),
            Phone("Galaxy M34", 6.5, 1080, 2400, 120),
            Phone("Galaxy S21", 6.2, 1080, 2400, 120),
            Phone("Galaxy S22", 6.1, 1080, 2340, 120),
            Phone("Galaxy S23", 6.1, 1080, 2340, 120),
            Phone("Galaxy S23 Ultra", 6.8, 1440, 3088, 120),
            Phone("Galaxy S24", 6.2, 1080, 2340, 120),
            Phone("Galaxy S24 Ultra", 6.8, 1440, 3120, 120)
        ),
        "Xiaomi / Redmi / Poco" to listOf(
            Phone("Redmi 9A", 6.53, 720, 1600, 60),
            Phone("Redmi 10", 6.5, 1080, 2400, 90),
            Phone("Redmi 12", 6.79, 1080, 2460, 90),
            Phone("Redmi 13C", 6.74, 720, 1600, 90),
            Phone("Redmi Note 10", 6.43, 1080, 2400, 60),
            Phone("Redmi Note 11", 6.43, 1080, 2400, 90),
            Phone("Redmi Note 12", 6.67, 1080, 2400, 120),
            Phone("Redmi Note 13", 6.67, 1080, 2400, 120),
            Phone("Redmi Note 13 Pro", 6.67, 1220, 2712, 120),
            Phone("Redmi Note 14", 6.67, 1080, 2400, 120),
            Phone("Poco X3 Pro", 6.67, 1080, 2400, 120),
            Phone("Poco X5 Pro", 6.67, 1080, 2400, 120),
            Phone("Poco X6 Pro", 6.67, 1220, 2712, 120),
            Phone("Poco M6 Pro", 6.79, 1080, 2460, 90),
            Phone("Poco F5", 6.67, 1080, 2400, 120),
            Phone("Poco F6", 6.67, 1220, 2712, 120),
            Phone("Xiaomi 13T", 6.67, 1220, 2712, 144)
        ),
        "Realme" to listOf(
            Phone("Realme C11", 6.5, 720, 1600, 60),
            Phone("Realme C21Y", 6.5, 720, 1600, 60),
            Phone("Realme C33", 6.5, 720, 1600, 60),
            Phone("Realme C53", 6.74, 720, 1600, 90),
            Phone("Realme C55", 6.72, 1080, 2400, 90),
            Phone("Realme Narzo 50A", 6.5, 720, 1600, 60),
            Phone("Realme Narzo 60", 6.43, 1080, 2400, 90),
            Phone("Realme 9i", 6.6, 1080, 2412, 90),
            Phone("Realme 10", 6.4, 1080, 2400, 90),
            Phone("Realme 11 Pro", 6.7, 1080, 2412, 120),
            Phone("Realme GT Neo 3", 6.7, 1080, 2412, 120),
            Phone("Realme GT 6T", 6.78, 1264, 2780, 120)
        ),
        "Oppo / Vivo" to listOf(
            Phone("Oppo A17", 6.56, 720, 1612, 60),
            Phone("Oppo A57", 6.56, 720, 1612, 90),
            Phone("Oppo A78", 6.43, 1080, 2400, 90),
            Phone("Oppo F21 Pro", 6.43, 1080, 2400, 90),
            Phone("Oppo Reno 8", 6.43, 1080, 2400, 90),
            Phone("Oppo Reno 10", 6.7, 1080, 2412, 120),
            Phone("Vivo Y12", 6.35, 720, 1544, 60),
            Phone("Vivo Y20", 6.51, 720, 1600, 60),
            Phone("Vivo Y21", 6.51, 720, 1600, 60),
            Phone("Vivo Y22", 6.55, 720, 1612, 90),
            Phone("Vivo Y27", 6.64, 1080, 2388, 90),
            Phone("Vivo T2", 6.38, 1080, 2400, 90),
            Phone("Vivo V23", 6.44, 1080, 2404, 90),
            Phone("Vivo V29", 6.78, 1260, 2800, 120),
            Phone("iQOO Neo 7", 6.78, 1080, 2400, 120)
        ),
        "Infinix / Tecno" to listOf(
            Phone("Infinix Smart 6", 6.6, 720, 1600, 60),
            Phone("Infinix Hot 10", 6.78, 720, 1640, 90),
            Phone("Infinix Hot 11S", 6.78, 1080, 2460, 90),
            Phone("Infinix Hot 20", 6.82, 720, 1640, 90),
            Phone("Infinix Hot 30", 6.78, 1080, 2460, 90),
            Phone("Infinix Hot 40 Pro", 6.78, 1080, 2460, 120),
            Phone("Infinix Note 12", 6.7, 1080, 2400, 60),
            Phone("Infinix Note 30", 6.78, 1080, 2460, 120),
            Phone("Infinix Zero 30", 6.78, 1080, 2400, 144),
            Phone("Tecno Spark 8", 6.6, 720, 1612, 90),
            Phone("Tecno Spark 10", 6.6, 720, 1612, 90),
            Phone("Tecno Camon 20", 6.67, 1080, 2400, 120),
            Phone("Tecno Pova 5", 6.78, 1080, 2460, 120)
        ),
        "OnePlus / Google / Moto / Other" to listOf(
            Phone("OnePlus Nord CE 3 Lite", 6.72, 1080, 2400, 120),
            Phone("OnePlus 11", 6.7, 1440, 3216, 120),
            Phone("Pixel 6a", 6.1, 1080, 2400, 60),
            Phone("Pixel 7", 6.3, 1080, 2400, 90),
            Phone("Moto G54", 6.5, 1080, 2400, 120),
            Phone("Nothing Phone 2a", 6.7, 1084, 2412, 120),
            Phone("Asus ROG Phone 6", 6.78, 1080, 2448, 165)
        ),
        "iPhone" to listOf(
            Phone("iPhone 7", 4.7, 750, 1334, 60, true),
            Phone("iPhone 8 Plus", 5.5, 1080, 1920, 60, true),
            Phone("iPhone X", 5.8, 1125, 2436, 60, true),
            Phone("iPhone XR", 6.1, 828, 1792, 60, true),
            Phone("iPhone 11", 6.1, 828, 1792, 60, true),
            Phone("iPhone 12", 6.1, 1170, 2532, 60, true),
            Phone("iPhone 13", 6.1, 1170, 2532, 60, true),
            Phone("iPhone 14", 6.1, 1170, 2532, 60, true),
            Phone("iPhone 14 Pro Max", 6.7, 1290, 2796, 120, true),
            Phone("iPhone 15", 6.1, 1179, 2556, 60, true),
            Phone("iPhone 15 Pro", 6.1, 1179, 2556, 120, true),
            Phone("iPhone 15 Pro Max", 6.7, 1290, 2796, 120, true)
        ),
    )
}

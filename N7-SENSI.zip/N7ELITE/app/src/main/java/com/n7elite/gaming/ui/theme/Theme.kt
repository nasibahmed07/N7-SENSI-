package com.n7elite.gaming.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val N7Red = Color(0xFFFF2E4D)
val N7Blue = Color(0xFF2EA8FF)

private val N7Scheme = darkColorScheme(
    primary = N7Red,
    secondary = N7Blue,
    background = Color(0xFF0B0D12),
    surface = Color(0xFF151922),
    onBackground = Color(0xFFEAF0FF),
    onSurface = Color(0xFFEAF0FF)
)

@Composable
fun N7Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = N7Scheme, content = content)
}

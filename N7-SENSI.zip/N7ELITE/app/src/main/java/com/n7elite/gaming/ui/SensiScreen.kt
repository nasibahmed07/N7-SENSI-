package com.n7elite.gaming.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.n7elite.gaming.data.Phones
import com.n7elite.gaming.logic.Engine
import com.n7elite.gaming.logic.Phone
import kotlin.math.abs

@Composable
fun SensiScreen(vm: AppViewModel, back: () -> Unit) {
    val cfg by vm.cfg.collectAsState()
    val d = vm.device
    val thisPhone = remember { Phone(d.model, d.screenInches, d.widthPx, d.heightPx, d.refreshHz, false, d.dpi) }
    val brands = remember { Phones.brands.keys.toList() }
    val ramOpts = listOf(2, 3, 4, 6, 8, 12)

    var useThis by remember { mutableStateOf(true) }
    var brandI by remember { mutableIntStateOf(0) }
    var modelI by remember { mutableIntStateOf(0) }
    var ramI by remember { mutableIntStateOf(ramOpts.indices.minByOrNull { abs(ramOpts[it] - d.ramGb * 1.05) } ?: 2) }
    var finI by remember { mutableIntStateOf(1) }
    var styI by remember { mutableIntStateOf(0) }
    var aim by remember { mutableIntStateOf(0) }
    var dpiText by remember { mutableStateOf(d.dpi.toString()) }
    var pname by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("") }

    val list = Phones.brands.getValue(brands[brandI])
    val phone = if (useThis) thisPhone else list[modelI.coerceAtMost(list.size - 1)]
    LaunchedEffect(useThis, brandI, modelI) { dpiText = phone.defaultDpi.toString() }
    val dpi = dpiText.toIntOrNull()?.coerceIn(200, 640) ?: phone.defaultDpi
    val res = Engine.calc(phone, ramOpts[ramI], finI + 2, styI, dpi, aim, cfg.offsets[phone.name] ?: 0)

    Frame("Sensitivity Manager", back) {
        GlassCard {
            Chips(listOf("This phone", "Pick a model"), if (useThis) 0 else 1) { useThis = it == 0 }
            if (!useThis) {
                Spacer(Modifier.height(8.dp))
                Picker("Brand", brands, brands[brandI]) { brandI = it; modelI = 0 }
                Spacer(Modifier.height(8.dp))
                Picker("Model", list.map { it.name }, list[modelI.coerceAtMost(list.size - 1)].name) { modelI = it }
            }
            KV("Phone", phone.name)
            KV("Screen", "%.2f inch, %d Hz".format(phone.inches, phone.hz))
            if (!phone.ios) {
                OutlinedTextField(
                    value = dpiText, onValueChange = { dpiText = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Screen DPI (type your own)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        }
        GlassCard {
            Text("RAM")
            Chips(ramOpts.map { "$it GB" }, ramI) { ramI = it }
            Spacer(Modifier.height(8.dp))
            Text("Fingers")
            Chips(listOf("2", "3", "4"), finI) { finI = it }
            Spacer(Modifier.height(8.dp))
            Text("Play style")
            Chips(Engine.styles, styI) { styI = it }
        }
        GlassCard {
            Text("Sensitivity (0 to 200)")
            Engine.names.forEachIndexed { i, n -> Bar(n, res.sens[i].toString(), res.sens[i] / 200f) }
            Spacer(Modifier.height(14.dp))
            Text("Button size (%)")
            res.buttons.forEach { Bar(it.first, "${it.second}%", it.second / 100f) }
        }
        GlassCard {
            Text("Headshot tuning")
            Text("Open Training Ground. Drag from the chest up to the head. Then tap what happened.", modifier = Modifier.padding(top = 4.dp))
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { aim = (aim - 6).coerceAtLeast(-30) }) { Text("Over the head") }
                Button(onClick = { aim = (aim + 6).coerceAtMost(30) }) { Text("Under the head") }
            }
            TextButton(onClick = { aim = 0 }) { Text("Reset tuning ($aim)") }
        }
        GlassCard {
            OutlinedTextField(value = pname, onValueChange = { pname = it.take(24) }, label = { Text("Profile name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    if (pname.isNotBlank()) {
                        val s = Engine.names.indices.joinToString(", ") { "${Engine.names[it]} ${res.sens[it]}" } +
                            " | Fire ${res.buttons[0].second}% | ${phone.name}, $dpi DPI"
                        vm.saveProfile(pname.trim(), s)
                        saved = "Saved. See it in Profiles."
                    }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Save profile") }
            if (saved.isNotEmpty()) Text(saved)
        }
    }
}

package com.n7elite.gaming.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.n7elite.gaming.ui.theme.N7Blue
import com.n7elite.gaming.ui.theme.N7Red
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun TrainingScreen(back: () -> Unit) {
    var running by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(30) }
    var hits by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }
    var tx by remember { mutableFloatStateOf(0.5f) }
    var ty by remember { mutableFloatStateOf(0.5f) }
    LaunchedEffect(running) {
        if (running) {
            left = 30
            while (left > 0) { delay(1000); left-- }
            running = false
        }
    }
    Frame("Aim Training", back) {
        GlassCard {
            Text("Tap the red circles for 30 seconds. Play one round per sensi setting and compare your hits and accuracy. These are your real taps, not estimates.")
            KV("Time left", "$left s")
            KV("Hits", hits.toString())
            KV("Missed taps", misses.toString())
            val total = hits + misses
            KV("Accuracy", if (total == 0) "-" else "${hits * 100 / total}%")
            Button(onClick = { hits = 0; misses = 0; running = true }, enabled = !running, modifier = Modifier.padding(top = 8.dp)) { Text("Start round") }
        }
        BoxWithConstraints(
            Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.06f))
                .pointerInput(running) { detectTapGestures { if (running) misses++ } }
        ) {
            if (running) {
                val size = 56.dp
                Box(
                    Modifier.offset(x = (maxWidth - size) * tx, y = (maxHeight - size) * ty).size(size)
                        .clip(CircleShape).background(N7Red)
                        .clickable { hits++; tx = Random.nextFloat(); ty = Random.nextFloat() }
                )
            }
        }
    }
}

@Composable
fun ProfilesScreen(vm: AppViewModel, back: () -> Unit) {
    val profiles by vm.profiles.collectAsState()
    Frame("Gaming Profiles", back) {
        if (profiles.isEmpty()) Text("No profiles yet. Save one from the Sensitivity Manager.")
        profiles.forEach { (name, text) ->
            GlassCard {
                Text(name, fontWeight = FontWeight.Bold, color = N7Blue)
                SelectionContainer { Text(text, modifier = Modifier.padding(top = 4.dp)) }
                TextButton(onClick = { vm.deleteProfile(name) }) { Text("Delete", color = N7Red) }
            }
        }
    }
}

private const val SAMPLE = """{
  "maintenance": false,
  "message": "Welcome to N7 ELITE",
  "minVersion": 1,
  "blocked": [],
  "offsets": { "Galaxy A15": 3 }
}"""

@Composable
fun AdminScreen(vm: AppViewModel, back: () -> Unit) {
    val cfg by vm.cfg.collectAsState()
    Frame("Admin status", back) {
        GlassCard {
            Text("Control file", fontWeight = FontWeight.Bold, color = N7Blue)
            Text("The app reads one online file when it opens. The link is built into the app.", modifier = Modifier.padding(top = 4.dp))
            KV("Status", if (cfg.ok) "Loaded" else if (cfg.error.isNotBlank()) "Error: ${cfg.error}" else "Loading")
            if (cfg.ok) {
                KV("Maintenance", if (cfg.maintenance) "ON" else "off")
                KV("Blocked devices", cfg.blocked.size.toString())
                KV("Model offsets", cfg.offsets.size.toString())
            }
            Button(onClick = { vm.refresh() }, modifier = Modifier.padding(top = 8.dp)) { Text("Reload now") }
        }
        GlassCard {
            Text("This device ID (add it to \"blocked\" to block this phone)", fontWeight = FontWeight.Bold, color = N7Blue)
            SelectionContainer { Text(vm.deviceId, modifier = Modifier.padding(top = 4.dp)) }
        }
        GlassCard {
            Text("Example file", fontWeight = FontWeight.Bold, color = N7Blue)
            SelectionContainer { Text(SAMPLE, modifier = Modifier.padding(top = 4.dp)) }
        }
    }
}

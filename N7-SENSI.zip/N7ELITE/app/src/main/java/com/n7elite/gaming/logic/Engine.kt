package com.n7elite.gaming.logic

import kotlin.math.roundToInt
import kotlin.math.sqrt

data class Phone(
    val name: String,
    val inches: Double,
    val w: Int,
    val h: Int,
    val hz: Int,
    val ios: Boolean = false,
    val baseDpi: Int? = null
) {
    val ppi: Double get() = sqrt((w.toDouble() * w + h.toDouble() * h)) / inches
    val defaultDpi: Int get() = baseDpi ?: (Math.round(ppi * 1.06 / 20.0) * 20).toInt()
}

data class Result(val sens: List<Int>, val buttons: List<Pair<String, Int>>)

/** Fixed rule. Same inputs always give the same numbers. */
object Engine {
    val names = listOf("General", "Red Dot", "2x Scope", "4x Scope", "AWM Scope", "Free Look")
    val styles = listOf("Rusher", "Balanced", "Sniper")
    private val base = listOf(
        listOf(188, 182, 170, 150, 115, 130),
        listOf(170, 166, 158, 145, 120, 125),
        listOf(150, 148, 150, 152, 135, 120)
    )
    private val w = listOf(1.0, 1.0, 0.6, 0.5, 0.4, 0.6)
    private val aimW = listOf(0.0, 1.0, 1.0, 1.0, 0.6, 0.0)

    private fun cl(v: Double, lo: Int, hi: Int) = v.roundToInt().coerceIn(lo, hi)

    fun calc(p: Phone, ram: Int, fingers: Int, style: Int, dpi: Int, aim: Int, extra: Int): Result {
        val ramA = when (ram) { 2 -> 10; 3 -> 8; 4 -> 3; 6 -> 0; 8 -> -2; else -> -4 }
        val hzA = if (p.hz >= 140) -10 else if (p.hz >= 110) -8 else if (p.hz >= 80) -4 else 0
        val finA = when (fingers) { 2 -> -4; 3 -> 0; else -> 4 }
        val dpiShift = if (p.ios) 0.0 else (dpi - p.defaultDpi) / 40.0
        val adj = (p.inches - 6.5) * 8 + hzA + ramA + finA + (if (p.ios) -6.0 else dpiShift * 6) + extra
        val sens = base[style].mapIndexed { i, v -> cl(v + adj * w[i] + aim * aimW[i], 1, 200) }
        val fb = when (fingers) { 2 -> 64; 3 -> 56; else -> 50 }
        val bf = fb + (6.5 - p.inches) * 5 + dpiShift * 2
        val buttons = listOf(
            "Fire button" to bf, "Scope button" to bf * 0.85, "Jump" to bf * 0.9,
            "Crouch" to bf * 0.8, "Reload" to bf * 0.75
        ).map { it.first to cl(it.second, 30, 100) }
        return Result(sens, buttons)
    }
}

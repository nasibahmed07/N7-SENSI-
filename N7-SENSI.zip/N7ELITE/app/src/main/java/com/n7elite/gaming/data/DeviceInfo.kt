package com.n7elite.gaming.data

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import kotlin.math.pow
import kotlin.math.sqrt

/** Real values read from this phone. Nothing here is made up. */
data class DeviceInfo(
    val brand: String,
    val model: String,
    val androidVersion: String,
    val ramGb: Double,
    val screenInches: Double,
    val widthPx: Int,
    val heightPx: Int,
    val dpi: Int,
    val refreshHz: Int
)

fun readDeviceInfo(context: Context): DeviceInfo {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mem = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mem)

    val dm = context.resources.displayMetrics
    val inches = sqrt(
        (dm.widthPixels / dm.xdpi).toDouble().pow(2) +
            (dm.heightPixels / dm.ydpi).toDouble().pow(2)
    )

    val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    val hz = displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f

    return DeviceInfo(
        brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        model = Build.MODEL,
        androidVersion = "Android ${Build.VERSION.RELEASE}",
        ramGb = mem.totalMem / 1_000_000_000.0,
        screenInches = inches,
        widthPx = dm.widthPixels,
        heightPx = dm.heightPixels,
        dpi = dm.densityDpi,
        refreshHz = hz.toInt()
    )
}

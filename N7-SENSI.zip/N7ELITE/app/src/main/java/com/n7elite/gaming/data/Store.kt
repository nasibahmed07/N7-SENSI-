package com.n7elite.gaming.data

import android.content.Context
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("n7", Context.MODE_PRIVATE)

    var configUrl: String
        get() = sp.getString("url", "") ?: ""
        set(v) { sp.edit().putString("url", v).apply() }

    fun profiles(): Map<String, String> {
        val o = JSONObject(sp.getString("profiles", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getString(it) }
    }

    fun saveProfile(name: String, text: String) {
        val o = JSONObject(sp.getString("profiles", "{}") ?: "{}")
        o.put(name, text)
        sp.edit().putString("profiles", o.toString()).apply()
    }

    fun deleteProfile(name: String) {
        val o = JSONObject(sp.getString("profiles", "{}") ?: "{}")
        o.remove(name)
        sp.edit().putString("profiles", o.toString()).apply()
    }
}

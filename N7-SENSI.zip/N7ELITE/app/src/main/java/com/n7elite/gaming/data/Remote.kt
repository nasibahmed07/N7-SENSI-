package com.n7elite.gaming.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class RemoteConfig(
    val ok: Boolean = false,
    val error: String = "",
    val maintenance: Boolean = false,
    val message: String = "",
    val minVersion: Int = 0,
    val blocked: List<String> = emptyList(),
    val offsets: Map<String, Int> = emptyMap()
)

suspend fun fetchConfig(url: String): RemoteConfig = withContext(Dispatchers.IO) {
    try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        val text = c.inputStream.bufferedReader().use { it.readText() }
        val o = JSONObject(text)
        val b = o.optJSONArray("blocked")
        val blocked = if (b == null) emptyList() else (0 until b.length()).map { b.getString(it) }
        val off = o.optJSONObject("offsets")
        val offsets = if (off == null) emptyMap() else off.keys().asSequence().associateWith { off.getInt(it) }
        RemoteConfig(
            ok = true,
            maintenance = o.optBoolean("maintenance", false),
            message = o.optString("message", ""),
            minVersion = o.optInt("minVersion", 0),
            blocked = blocked,
            offsets = offsets
        )
    } catch (e: Exception) {
        RemoteConfig(ok = false, error = e.message ?: "Could not load the config")
    }
}
